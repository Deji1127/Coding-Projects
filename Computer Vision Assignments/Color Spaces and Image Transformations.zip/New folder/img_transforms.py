import numpy as np
import cv2
from color_space_test import rgb_to_hsv, hsv_to_rgb
def random_crop(img, size):
    height, width = img.shape[:2]

    if size <= 0 or size > min(width, height):
        raise ValueError("Crop size must be within (0, min(width, height)]")

    max_x = width - size
    max_y = height - size

    center_x = np.random.randint(size // 2, max_x + 1 - size // 2)
    center_y = np.random.randint(size // 2, max_y + 1 - size // 2)

    left = center_x - size // 2
    top = center_y - size // 2
    right = left + size
    bottom = top + size

    cropped_img = img[top:bottom, left:right]

    return cropped_img
def extract_patch(img, num_patches):
    height = img.shape[:2]

    patch_size = height // num_patches

    patches = []

    for i in range(num_patches):
        for j in range(num_patches):
            top = i * patch_size
            left = j * patch_size
            bottom = top + patch_size
            right = left + patch_size

            patch = img[top:bottom, left:right]

            patches.append(patch)

    return patches
def resize_img(img, factor):
    new_height = int(img.shape[0] * factor)
    new_width = int(img.shape[1] * factor)

    resized_img = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_NEAREST)

    return resized_img
def color_jitter(img, hue, saturation, value):    
    dh = np.random.uniform(-hue, hue)
    ds = np.random.uniform(-saturation, saturation)
    dv = np.random.uniform(-value, value)

    hsv_img = rgb_to_hsv(img / 255.0)

    hsv_img[:, :, 0] += dh
    hsv_img[:, :, 1] += ds
    hsv_img[:, :, 2] += dv

    hsv_img[:, :, 0] = np.clip(hsv_img[:, :, 0], 0, 1)
    hsv_img[:, :, 1] = np.clip(hsv_img[:, :, 1], 0, 1)
    hsv_img[:, :, 2] = np.clip(hsv_img[:, :, 2], 0, 1)

    modified_img = hsv_to_rgb(hsv_img) * 255.0

    return modified_img.astype(np.uint8)


# Test random_crop function
# img = np.random.randint(0, 255, (500, 500, 3), dtype=np.uint8)
# size = 250
# cropped_img = random_crop(img, size)
# cv2.imshow("Random Crop", cropped_img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
# cv2.imwrite("Output.png", cropped_img)

# Test extract_patch function
# img = np.random.randint(0, 255, (512, 512, 3), dtype=np.uint8)
# num_patches = 4
# patches = extract_patch(img, num_patches)
# for i, patch in enumerate(patches):
#     cv2.imshow(f"Patch {i+1}", patch)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

# # # Test resize_img function
# img = cv2.imread("input_image.jpg")  # Replace "input_image.jpg" with your actual image filename
# factor = 0.5
# resized_img = resize_img(img, factor)
# cv2.imshow("Resized Image", resized_img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

# Test color_jitter function
# img = cv2.imread("Lumatic Headshot.jpg") 
# hue = 0.2
# saturation = 0.3
# value = 0.4
# jittered_img = color_jitter(img, hue, saturation, value)
# cv2.imshow("Jittered Image", jittered_img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
