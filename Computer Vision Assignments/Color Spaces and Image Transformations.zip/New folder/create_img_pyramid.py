import cv2
import numpy as np

def resize_img(img, factor):

    new_height = int(img.shape[0] * factor)
    new_width = int(img.shape[1] * factor)

    resized_img = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_NEAREST)

    return resized_img

def create_image_pyramid(img, pyramid_height):
    pyramid = []

    for i in range(1, pyramid_height + 1):
        scale_factor = 2 ** i
        resized_img = resize_img(img, 1 / scale_factor)
        pyramid.append(resized_img)

        output_filename = f"Output_{scale_factor}x.png"
        cv2.imwrite(output_filename, resized_img)

    return pyramid

img = cv2.imread("Input.jpg")
pyramid_height = 4
image_pyramid = create_image_pyramid(img, pyramid_height)