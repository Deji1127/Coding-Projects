import numpy as np
import cv2

def rgb_to_hsv(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    v = maxc
    delta = maxc - minc
    s = delta / np.where(maxc != 0, maxc, 1)
    s = np.where(delta != 0, s, 0)
    rc = np.where(maxc == r, (g - b) / delta, 
                  np.where(maxc == g, 2.0 + (b - r) / delta, 
                           4.0 + (r - g) / delta))
    h = (rc / 6.0) % 1.0
    h = np.where(delta != 0, h, 0)
    return np.dstack((h, s, v))

def hsv_to_rgb(hsv):
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    p = np.zeros_like(h)
    q = np.zeros_like(h)
    t = np.zeros_like(h)
    i = (h * 6.0).astype(int)
    f = (h * 6.0) - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    i = i % 6
    result = np.zeros_like(hsv)
    result[..., 0] = np.choose(i, [v, q, p, p, t, v])
    result[..., 1] = np.choose(i, [t, v, v, q, p, p])
    result[..., 2] = np.choose(i, [p, p, t, v, v, q])
    return result

def modify_hsv(image, dh, ds, dv):
    hsv_image = rgb_to_hsv(image)
    hsv_image[..., 0] = (hsv_image[..., 0] + dh) % 1.0
    hsv_image[..., 1] = np.clip(hsv_image[..., 1] + ds, 0, 1)
    hsv_image[..., 2] = np.clip(hsv_image[..., 2] + dv, 0, 1)
    return hsv_to_rgb(hsv_image)

input_filename = input('Enter a filename: ')
hvm_value = None
sat_mod = None
val_mod = None
while hvm_value is None or not (0 <= hvm_value <= 1):
        hvm_value = int(input('Enter a Hue value modification value between [0, 360]: ')) / 360.0
        if not (0 <= hvm_value <= 1):
            print("Hue value modification value should be between 0 and 360 degrees.")
    
while sat_mod is None or not (0 <= sat_mod <= 1):
        sat_mod = float(input('Enter a Saturation modification value between [0, 1]: '))
        if not (0 <= sat_mod <= 1):
            print("Saturation modification value should be between 0 and 1.")

while val_mod is None or not (0 <= val_mod <= 1):
        val_mod = float(input('Enter a value modification between [0, 1]: '))
        if not (0 <= val_mod <= 1):
            print("Value modification value should be between 0 and 1.")

image = cv2.imread(input_filename)
modified_image = modify_hsv(image / 255.0, hvm_value, sat_mod, val_mod) * 255.0
cv2.imwrite("Output.png", modified_image)


