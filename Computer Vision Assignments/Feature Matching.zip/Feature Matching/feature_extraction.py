import numpy as np
from skimage.feature import hog
import cv2

def extract_sift_features(images):
    sift = cv2.SIFT_create()
    features = []
    for image in images:
        _, descriptors = sift.detectAndCompute(image, None)
        if descriptors is not None:
            features.append(descriptors)
    return features

def extract_hog_features(images):
    features = []
    for image in images:
        feature_vector = hog(image, pixels_per_cell=(8, 8), cells_per_block=(2, 2))
        features.append(feature_vector)
    return features

if __name__ == "__main__":
    # Load the pre-split data
    data = np.load("cifar10.npz")

    # Extract features from the training data
    X_train_sift = extract_sift_features(data["X_train"])
    X_train_hog = extract_hog_features(data["X_train"])

    # Extract features from the testing data
    X_test_sift = extract_sift_features(data["X_test"])
    X_test_hog = extract_hog_features(data["X_test"])

    # Save the extracted features to a file
    np.savez("cifar10_features.npz", X_train_sift=X_train_sift, X_train_hog=X_train_hog,
             X_test_sift=X_test_sift, X_test_hog=X_test_hog,
             y_train=data["y_train"], y_test=data["y_test"])
