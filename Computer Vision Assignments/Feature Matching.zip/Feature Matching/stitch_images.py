import cv2
import numpy as np
import matplotlib.pyplot as plt
import numpy.testing as npt
from scipy.spatial.distance import cdist
from skimage.feature import match_descriptors
def match_keypoints(des1, des2, threshold=0.75):
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)

    # Apply ratio test
    good_matches = []
    for m, n in matches:
        if m.distance < threshold * n.distance:
            good_matches.append(m)

    return good_matches

def plot_matches(img1, kp1, img2, kp2, matches):
    # Create a new image with the two input images side by side
    h1, w1 = img1.shape[:2]
    h2, w2 = img2.shape[:2]
    new_img = np.zeros((max(h1, h2), w1 + w2, 3), dtype=np.uint8)
    new_img[:h1, :w1] = img1
    new_img[:h2, w1:w1 + w2] = img2

    # Draw keypoints and matches
    for match in matches:
        idx1 = match.queryIdx
        idx2 = match.trainIdx
        pt1 = (int(kp1[idx1].pt[0]), int(kp1[idx1].pt[1]))
        pt2 = (int(kp2[idx2].pt[0]) + w1, int(kp2[idx2].pt[1]))
        cv2.circle(new_img, pt1, 5, (0, 255, 0), -1)
        cv2.circle(new_img, pt2, 5, (0, 255, 0), -1)
        cv2.line(new_img, pt1, pt2, (255, 0, 0), 2)

    # Plot the image
    plt.imshow(cv2.cvtColor(new_img, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.show()

def get_matching_indices(kp1, kp2, matches):
    indices1 = [match.queryIdx for match in matches]
    indices2 = [match.trainIdx for match in matches]

    return indices1, indices2

def compute_affine_transform(src_points, dst_points):
    # Add a column of ones to src_points to account for translation
    src_points = np.hstack((src_points, np.ones((src_points.shape[0], 1))))
    
    # Compute the affine transformation matrix using the normal equations
    M_affine = np.linalg.lstsq(src_points, dst_points, rcond=None)[0]
    
    return M_affine

def compute_projective_transform(src_points, dst_points):
    # Add a column of ones to src_points to account for perspective divide
    src_points = np.hstack((src_points, np.ones((src_points.shape[0], 1))))
    
    # Construct the A matrix for the homography estimation
    A = []
    for i in range(len(src_points)):
        x, y = src_points[i]
        u, v = dst_points[i]
        A.append([x, y, 1, 0, 0, 0, -u*x, -u*y, -u])
        A.append([0, 0, 0, x, y, 1, -v*x, -v*y, -v])
    A = np.asarray(A)
    
    # Solve for the homography matrix using SVD
    _, _, V = np.linalg.svd(A)
    h = V[-1,:] / V[-1,-1]  # Normalize by last element
    M_projective = h.reshape(3, 3)
    
    return M_projective

def ransac(keypoints_src, keypoints_dst, num_iterations, min_samples, threshold):
    best_model = None
    best_inliers = 0
    
    for _ in range(num_iterations):
        # Randomly sample min_samples keypoints
        sample_indices = np.random.choice(len(keypoints_src), min_samples, replace=False)
        src_sample = keypoints_src[sample_indices]
        dst_sample = keypoints_dst[sample_indices]
        
        # Compute the transformation matrix
        if min_samples == 3:
            model = compute_projective_transform(src_sample, dst_sample)
        else:
            model = compute_affine_transform(src_sample, dst_sample)
        
        # Compute the distances between transformed keypoints and actual keypoints
        transformed_points = np.dot(model, np.vstack((keypoints_src.T, np.ones((1, len(keypoints_src))))))
        transformed_points = transformed_points[:2, :] / transformed_points[2, :]
        distances = np.linalg.norm(transformed_points.T - keypoints_dst, axis=1)
        
        # Count inliers
        num_inliers = np.sum(distances < threshold)
        
        # Update best model if we found more inliers
        if num_inliers > best_inliers:
            best_model = model
            best_inliers = num_inliers
    
    return best_model


# Load images
img1 = cv2.imread('image1.jpg', cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread('image2.jpg', cv2.IMREAD_GRAYSCALE)

# Detect keypoints and compute descriptors
orb = cv2.ORB_create()
kp1, des1 = orb.detectAndCompute(img1, None)
kp2, des2 = orb.detectAndCompute(img2, None)

# Match keypoints
matches = match_keypoints(des1, des2)

# Get matching indices
indices1, indices2 = get_matching_indices(kp1, kp2, matches)

# Use match_descriptors function to get matching indices
matches_skimage = match_descriptors(des1, des2)

# Compare indices
npt.assert_array_equal(matches_skimage, np.column_stack((indices1, indices2)))

# Plot matches
plot_matches(img1, kp1, img2, kp2, matches)
